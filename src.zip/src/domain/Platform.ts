export enum Platform {
    US = 'US',
    NL = 'NL',
    FR = 'FR',
    DE = 'DE',
    CH = 'CH',
    IT = 'IT',
    PL = 'PL',
    ES = 'ES',
}
