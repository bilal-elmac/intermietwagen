export enum SortStatus {
    PRICE_ASC = 1,
    SUPPLIER_RATING_DESC = 2,
}
