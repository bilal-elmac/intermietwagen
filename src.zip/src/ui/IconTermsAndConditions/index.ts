export { IconTermsAndConditions as default } from './IconTermsAndConditions';
