export { InfoButton as default } from './InfoButton';
