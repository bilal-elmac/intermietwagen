import { NavigationButtonComponent as NavigationButton } from './NavigationButton';
export default NavigationButton;
