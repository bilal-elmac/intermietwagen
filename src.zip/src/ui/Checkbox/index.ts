import { Checkbox, Args } from './Checkbox';

export { Args as CheckboxArgs };
export default Checkbox;
