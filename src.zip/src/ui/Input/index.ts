import Input, { InputProps } from './Input';
export { InputProps };
export default Input;
