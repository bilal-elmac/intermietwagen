export { PriceLabel as default } from './PriceLabel';
