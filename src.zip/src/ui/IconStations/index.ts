export { Railway, City, Airport, Ferry, Hotel, Shuttle } from './IconStations';
