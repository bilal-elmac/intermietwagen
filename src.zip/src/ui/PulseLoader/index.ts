export {
    PulseLoader as default,
    WhitesmokePatch,
    WhitePatch,
    TransparentPatch,
    Moldure,
    BASE_CLASS as PulseLoaderBaseClass,
} from './PulseLoader';
