export { IconBulb as default } from './IconBulb';
