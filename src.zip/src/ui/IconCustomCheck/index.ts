export { IconCustomCheck as default } from './IconCustomCheck';
