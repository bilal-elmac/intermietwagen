export { Rating as default, FormattedRating, DEFAULT_STAR_COUNT } from './Rating';
