export { CleanWheelIcon as default } from './CleanWheelIcon';
