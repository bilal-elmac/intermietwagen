export { RatingBarChart as default } from './RatingBarChart';
