export { IconAC as default } from './IconAC';
