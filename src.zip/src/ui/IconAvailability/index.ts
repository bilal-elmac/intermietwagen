export { IconAvailability as default, AvailabilityStatus } from './IconAvailability';
