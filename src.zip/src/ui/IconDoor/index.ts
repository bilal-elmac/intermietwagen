export { IconDoor as default } from './IconDoor';
