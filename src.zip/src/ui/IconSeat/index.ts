export { IconSeat as default } from './IconSeat';
