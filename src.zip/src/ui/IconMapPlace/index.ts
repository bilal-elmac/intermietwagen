export { IconMapPlace as default } from './IconMapPlace';
