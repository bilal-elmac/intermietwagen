export { IconPayment as default } from './IconPayment';
