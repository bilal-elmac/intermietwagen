export { LogoComponent as Logo, LogoNoText } from './Logo';
