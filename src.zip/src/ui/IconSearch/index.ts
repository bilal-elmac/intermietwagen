export { IconSearch as default } from './IconSearch';
