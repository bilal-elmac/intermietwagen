export { ExtraPill as default } from './ExtraPill';
