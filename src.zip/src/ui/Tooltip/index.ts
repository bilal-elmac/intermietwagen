export { Tooltip as default } from './Tooltip';
