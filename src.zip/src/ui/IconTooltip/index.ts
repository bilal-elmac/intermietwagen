export { TooltipIcon as default } from './IconTooltip';
