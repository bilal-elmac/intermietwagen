export { IconClose as default } from './IconClose';
