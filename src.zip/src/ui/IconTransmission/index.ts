export { IconTransmission as default } from './IconTransmission';
