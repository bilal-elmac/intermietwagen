export { IconBag as default } from './IconBag';
