export { IconAdult as default } from './IconAdult';
