export { IconTelephone as default } from './IconTelephone';
