/*
 * These are here because of IE11 :)
 */
import '@formatjs/intl-pluralrules/polyfill';
import '@formatjs/intl-pluralrules/dist/locale-data/de';
import '@formatjs/intl-pluralrules/dist/locale-data/gsw';
import '@formatjs/intl-pluralrules/dist/locale-data/en';
import '@formatjs/intl-pluralrules/dist/locale-data/es';
import '@formatjs/intl-pluralrules/dist/locale-data/fr';
import '@formatjs/intl-pluralrules/dist/locale-data/it';
import '@formatjs/intl-pluralrules/dist/locale-data/nl';
import '@formatjs/intl-pluralrules/dist/locale-data/pl';
import '@formatjs/intl-getcanonicallocales/polyfill';
import 'core-js/modules/es.promise';
import 'core-js/modules/es.map';
import 'core-js/es/array';
import 'core-js/es/object';
import 'core-js/es/string';
import 'core-js/web/url-search-params';
import 'core-js/modules/web.dom-collections.for-each';
