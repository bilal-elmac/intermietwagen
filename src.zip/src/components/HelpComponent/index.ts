import { HelpComponent } from './HelpComponent';

export default HelpComponent;
