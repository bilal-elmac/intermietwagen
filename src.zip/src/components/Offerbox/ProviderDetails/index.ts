export { ProviderDetails as default } from './ProviderDetails';
