export { SupplierWarningSection as default } from './SupplierWarning';
