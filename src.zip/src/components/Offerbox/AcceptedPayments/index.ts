export { AcceptedPayments as default } from './AcceptedPayments';
