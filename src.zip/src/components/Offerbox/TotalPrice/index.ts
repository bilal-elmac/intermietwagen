export { TotalPrice as default } from './TotalPrice';
