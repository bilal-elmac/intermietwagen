export { VehicleCharacteristics as default } from './VehicleCharacteristics';
