export { ReducedLocationDetails as default, LocationDetails, Props } from './LocationDetails';
