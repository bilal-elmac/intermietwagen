export { PaymentDetails as default } from './PaymentDetails';
