export { CarInfo as default } from './CarInfo';
