export { SupplierProviderLogos as default } from './SupplierProviderLogos';
