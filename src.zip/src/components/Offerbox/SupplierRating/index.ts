export { SupplierRating as default } from './SupplierRating';
