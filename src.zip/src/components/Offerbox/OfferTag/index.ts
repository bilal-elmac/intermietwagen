export { OfferTag as default } from './OfferTag';
