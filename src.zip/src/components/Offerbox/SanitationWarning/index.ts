export { SanitationWarning as default } from './SanitationWarning';
