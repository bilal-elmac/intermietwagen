import { PaginationComponent } from './Pagination';
export default PaginationComponent;
