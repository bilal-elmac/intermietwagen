export { FilterView as default } from './FilterView';
