import FilterView from './FilterView';

export default FilterView;
