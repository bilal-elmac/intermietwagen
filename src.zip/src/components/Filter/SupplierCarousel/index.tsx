export { SupplierCarousel as default } from './SupplierCarousel';
