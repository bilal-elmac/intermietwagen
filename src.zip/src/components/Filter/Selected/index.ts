export { SelectedFilters as default } from './SelectedFilters';
