export { QuickFilters as default } from './QuickFilters';
