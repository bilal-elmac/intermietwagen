export { LeftSideFilter as default } from './LeftSideFilter';
