export { OffersSummary as default } from './OffersSummary';
