import { SearchComponent } from './SearchComponent';
export default SearchComponent;
