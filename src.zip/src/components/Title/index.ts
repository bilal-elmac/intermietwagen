export { Title as default } from './Title';
