export { AboutBanner as default } from './AboutBanner';
