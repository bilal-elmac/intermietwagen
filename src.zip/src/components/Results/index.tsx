import { ResultsView } from './ResultsView';

export default ResultsView;
