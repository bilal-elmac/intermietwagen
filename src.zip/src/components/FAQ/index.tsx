import { FAQComponent as FAQ } from './FAQComponent';
export default FAQ;
