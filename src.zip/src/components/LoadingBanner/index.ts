export { LoadingBanner as default } from './LoadingBanner';
