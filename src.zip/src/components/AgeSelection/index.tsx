import { AgeSelectionComponent } from './AgeSelection';
export default AgeSelectionComponent;
